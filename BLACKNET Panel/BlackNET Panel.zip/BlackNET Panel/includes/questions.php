<?php
$questions = [
    "Select a Security Question",
    "What was your childhood nickname?",
    "What is the name of your favorite childhood friend?",
    "What was the name of your first stuffed animal?",
    "Where were you when you had your first kiss?",
    "What is the name of the company of your first job?",
    "What was your favorite place to visit as a child?",
    "What was your dream job as a child?",
    "What is your preferred musical genre?",
    "What is your favorite team?",
    "What is your father's middle name?",
];
