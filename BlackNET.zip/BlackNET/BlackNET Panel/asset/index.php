<!DOCTYPE html>
<html>

<head>
	<title>403 - Access Denied</title>
</head>

<body>
	<h1>Access Denied!</h1>
	<p>you don't have permission to view this page</p>
</body>

</html>
<?php http_response_code(403); ?>