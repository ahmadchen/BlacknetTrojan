<?php
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "botnet");
define("ADMIN_EMAIL", "Admin Email");
define("APP_PATH", dirname(__FILE__,2) . "/"); // Don't Change
define("APP_VERSION", "v3.5.1"); // Don't Change
