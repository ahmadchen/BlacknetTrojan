﻿Public Class Plugin
    Public Function Run() ' Important Function
        MsgBox("This is my plugin")
        Return True
    End Function
End Class