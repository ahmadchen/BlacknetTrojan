<p align="center">
 <img src="https://a.top4top.io/p_1104t3ole1.png" alt="" />
</p>

<p align="center">
 <a href="#"><img align="center" src="https://img.shields.io/maintenance/no/2020" /></a> 
</p>

# BlackNET
Free advanced and modern Windows botnet with a nice and secure PHP panel developed using VB.NET.

## About BlackNET

# This Project is Deprecated

This repository will be updated when needed.

No major features will be added just bug fixes.

## What You Can Do
 1. Upload File
 2. DDOS Attack [ TCP,UDP,ARME,Slowloris, HTTPGet, POSTHttp, Bandwidth Flood ]
    + Start DDOS
    + Stop DDOS
 3. Open Webpage
     + Visible
     + Hidden
 4. Show MessageBox
 5. Take Screenshot
 6. Steal Firefox Cookies
 7. Steal Saved Passwords [ Chrome, Firefox ]
 8. Steal Chrome Cookies
 9. Steal Discord Token
 10. Steal Chrome Hisory
 11. Execute Shell Commands [ CMD, Powershell ]
 12. Send Spam Emails
 13. Keylogger
 14. Execute Scripts
 15. Computer Operations
     + Restart
     + Shutdown
     + Logout
 16. Bitcoint Wallet Stealer
 17. Uninstall Client
 18. Move Client
 19. Blacklist Client
 20. Close Client
 
## Requirements
1. PHP >=  7.0
    + cURL
    + php_cURL
2. NET Framework
    + Stub >= 2.0
    + Builder >= 4.0

## How to Install PHP Panel
1. Clone this Repo
2. Compress BlackNET panel folder and upload it to your hosting
3. Create a database with any name you want
4. Change the database information in config/config.sample.php
5. Rename config.sample.php to config.php
6. Change files and folders permission to 777 [ Uploads Folder, Scripts Folder ]
7. Make Sure that all DLLs are included in Plugins Folder
8. Go to install.php to create the botnet tables automatically
9. Enable a Cron Job for ping.php and remove.php

## How to secure BlackNET
1. Remove install.php and update.php
2. Change username and password
3. Add an email address to your account
4. Enable Captcha using Google reCaptcha v2
5. Enable 2FA on your account

## How to use the File Searcher Function
1. execute command on the client
2. use this pattern ``` %Userprofile%|[Here write extension list] ```
3. Wait untile the plugin finish the process and upload the files

Pattern Example:
```
%Userprofile%|[jpg,png,docx,pdf,logs,txt,pptx,psd,rtf]
```


## YouTube Tutorials
[How to install BlackNET v3.5.1](https://youtu.be/cijbJ7s6IXA)

[How to obfuscate BlackNET](https://www.youtube.com/watch?v=hzC8_UYGor0)

[How to Setup BlackNET Cron Job System](https://www.youtube.com/watch?v=rHCYGRA1h54)


## Thanks to
- KFC
- NYAN CAT
- omerfademir

## LEGAL DISCLAIMER PLEASE READ!
##### I, the creator and all those associated with the development and production of this program are not responsible for any actions and or damages caused by this software. You bear the full responsibility of your actions and acknowledge that this software was created for educational purposes only. This software's intended purpose is NOT to be used maliciously, or on any system that you do not have own or have explicit permission to operate and use this program on. By using this software, you automatically agree to the above.

## License
This project is licensed under the MIT License


## Copyright
[![Open Source Love svg1](https://badges.frapsoft.com/os/v1/open-source.png?v=103)](https://github.com/ellerbrock/open-source-badges/) 

Copyright © Black.Hacker - 2020
